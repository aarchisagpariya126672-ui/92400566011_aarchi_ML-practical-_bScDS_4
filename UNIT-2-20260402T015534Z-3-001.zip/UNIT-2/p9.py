#Missing Data handling and remove null data
#Missing Data
import pandas as pd
df = pd.read_csv("airlines.csv")
print("Missing Values:")
print(df.isnull().sum())
#Removing Null Data
ds = df.dropna()
print("After Removing Null Values:")
print(ds.shape)

Output:
Missing Values:
Airline ID       0
Name             0
Alias          506
IATA          4627
ICAO            87
Callsign       808
Country         15
Active           0
dtype: int64
After Removing Null Values:
(1010, 8)
