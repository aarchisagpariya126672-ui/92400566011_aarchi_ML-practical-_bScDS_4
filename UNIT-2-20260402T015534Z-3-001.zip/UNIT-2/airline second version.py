#Second Version - This is crreates separate columns for each category

import pandas as pd
# Load dataset
df = pd.read_csv("auto-mpg.csv")
#apply one-hot encoding on 'origin'
df_encoded = pd.get_dummies(df, columns=["origin"])
print("One-Hot Encoded Data:\n")
print(df_encoded.head())


Output:
One-Hot Encoded Data:

    mpg  cylinders  displacement  ... origin_1  origin_2  origin_3
0  18.0          8         307.0  ...     True     False     False
1  15.0          8         350.0  ...     True     False     False
2  18.0          8         318.0  ...     True     False     False
3  16.0          8         304.0  ...     True     False     False
4  17.0          8         302.0  ...     True     False     False

[5 rows x 11 columns]
