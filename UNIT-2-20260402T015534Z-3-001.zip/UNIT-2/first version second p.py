#first version

import pandas as pd


#read dataset
#df = pd.read_csv("auto-mpg.csv")
df = pd.read_csv("auto-mpg.csv" , na_values='?')

#find numeric attributes
print("numeric attributes:")
print(df.select_dtypes(include='number').columns)

#find categorical attributes
print("\ncategorical attributes:")
print(df.select_dtypes(include=['object','string']).columns)


output:
numeric attributes:
Index(['mpg', 'cylinders', 'displacement', 'horsepower', 'weight',
       'acceleration', 'model year', 'origin'],
      dtype='object')

categorical attributes:
Index(['car name'], dtype='object')
                            
