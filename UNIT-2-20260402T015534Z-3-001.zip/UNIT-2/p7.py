#read data set
import pandas as pd

ds = pd.read_csv("airlines.csv")

print("Dataset Records")
print(ds.head(10))

Output:
Dataset Records
   Airline ID  ... Active
0          -1  ...      Y
1           1  ...      Y
2           2  ...      N
3           3  ...      Y
4           4  ...      N
5           5  ...      N
6           6  ...      N
7           7  ...      N
8           8  ...      N
9           9  ...      N

[10 rows x 8 columns]
