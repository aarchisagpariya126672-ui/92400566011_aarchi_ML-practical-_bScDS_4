import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

#load dataset
df = pd.read_csv("auto-mpg.csv")

#replace '?' and convert horsepower to numeric
df["horsepower"] = df["horsepower"].replace("?",np.nan)
df["horsepower"] = pd.to_numeric(df["horsepower"])

#fill missing values with mean
df["horsepower"] = df["horsepower"].fillna(df["horsepower"].mean())

#select numeric columns only
num_cols = df.select_dtypes(include=['int64','float'])

#apply Min-Max Scalling
scaler = MinMaxScaler()
scaleddata = scaler.fit_transform(num_cols)

#convert back to DataFrame
scaleddf = pd.DataFrame(scaleddata, columns=num_cols.columns)

print("rescaled Data : \n")
print(scaleddf.head(10))


output:
rescaled Data : 

        mpg  cylinders  displacement  ...  acceleration  model year  origin
0  0.239362        1.0      0.617571  ...      0.238095         0.0     0.0
1  0.159574        1.0      0.728682  ...      0.208333         0.0     0.0
2  0.239362        1.0      0.645995  ...      0.178571         0.0     0.0
3  0.186170        1.0      0.609819  ...      0.238095         0.0     0.0
4  0.212766        1.0      0.604651  ...      0.148810         0.0     0.0
5  0.159574        1.0      0.932817  ...      0.119048         0.0     0.0
6  0.132979        1.0      0.997416  ...      0.059524         0.0     0.0
7  0.132979        1.0      0.961240  ...      0.029762         0.0     0.0
8  0.132979        1.0      1.000000  ...      0.119048         0.0     0.0
9  0.159574        1.0      0.832041  ...      0.029762         0.0     0.0

[10 rows x 8 columns]
