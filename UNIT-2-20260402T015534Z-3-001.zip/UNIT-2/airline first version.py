#Encoding Data
#First Version-Converts categories into numbers.

import pandas as pd
from sklearn.preprocessing import LabelEncoder
#Load dataset
ds=pd.read_csv("auto-mpg.csv")
#create LabelEncoder object
label_enc = LabelEncoder()
#Encode 'origin' column
ds["origin_encoded"] = label_enc.fit_transform(ds["origin"])
print("Encoded Data(origin column):\n")
print(ds[["origin","origin_encoded"]].head(10))

Output:
Encoded Data(origin column):

   origin  origin_encoded
0       1               0
1       1               0
2       1               0
3       1               0
4       1               0
5       1               0
6       1               0
7       1               0
8       1               0
9       1               0

