#identify category
import pandas as pd
df= pd.read_csv("airlines.csv")
print("Numeric Columns:")
print(df.select_dtypes(include=['int64', 'float64']).columns)
print("\nCategorical Columns:")
print(df.select_dtypes(include=['object']).columns)

output:
Numeric Columns:
Index(['Airline ID'], dtype='object')

Categorical Columns:
Index(['Name', 'Alias', 'IATA', 'ICAO', 'Callsign', 'Country', 'Active'], dtype='object')
