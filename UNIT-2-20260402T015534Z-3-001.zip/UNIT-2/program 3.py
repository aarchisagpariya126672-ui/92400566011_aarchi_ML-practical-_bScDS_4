import pandas as pd
import numpy as np

#load dataset
ds = pd.read_csv("auto-mpg.csv")

#replace '?' with NaN - Not a Number
ds["horsepower"] = ds["horsepower"].replace("?" , np.nan)

#convert horsepower to numeric
ds["horsepower"] = pd.to_numeric(ds["horsepower"])

#missing values checking
print("missing values before filling:\n")
print(ds.isnull().sum())

#fill missing values with mean
ds["horsepower"] = ds["horsepower"].fillna(ds["horsepower"].mean())

print("\nmissing values after filling:\n")
print(ds.isnull().sum())


output:
missing values before filling:

mpg             0
cylinders       0
displacement    0
horsepower      6
weight          0
acceleration    0
model year      0
origin          0
car name        0
dtype: int64

missing values after filling:

mpg             0
cylinders       0
displacement    0
horsepower      0
weight          0
acceleration    0
model year      0
origin          0
car name        0
dtype: int64

