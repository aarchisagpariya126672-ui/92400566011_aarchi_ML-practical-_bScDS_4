import pandas as pd
#read dataset
df = pd.read_csv("auto-mpg.csv",na_values='?')

#numeric columns
num_cols = df.select_dtypes(include='number').columns

#categorical columns
cat_cols = df.select_dtypes(exclude='number').columns

print("numeric attributes:")
print(list(num_cols))

print("\ncategorical attributes:")
print(list(cat_cols))



output:
numeric attributes:
['mpg', 'cylinders', 'displacement', 'horsepower', 'weight', 'acceleration', 'model year', 'origin']

categorical attributes:
['car name']
