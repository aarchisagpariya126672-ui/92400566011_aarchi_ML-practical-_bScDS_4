#rescaling data - min-max scaling
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
df = pd.read_csv("airlines.csv")
numeric_cols = df.select_dtypes(include=['int64','float'])
scaler = MinMaxScaler()
df[numeric_cols.columns] = scaler.fit_transform(numeric_cols)
print("Rescaled Data:")
print(df.head())

'''
output:
Rescaled Data:
   Airline ID  ... Active
0    0.000000  ...      Y
1    0.000094  ...      Y
2    0.000141  ...      N
3    0.000188  ...      Y
4    0.000235  ...      N

[5 rows x 8 columns]
'''
