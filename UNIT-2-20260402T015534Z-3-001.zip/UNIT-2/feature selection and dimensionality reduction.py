#feature selection and dimensionality reduction
#PCA - Practical component Analysis
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
# Load dataset
df = pd.read_csv("auto-mpg.csv")
#clean horsepower
df["horsepower"] = df["horsepower"].replace("?",np.nan)
df["horsepower"] = pd.to_numeric(df["horsepower"])
df["horsepower"] = df["horsepower"].fillna(df["horsepower"].mean())
#select numeric features
X = df.select_dtypes(include=['int64' , 'float64']).drop ("mpg" , axis=1)
#standardize data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
#apply PCA (reduce to 2 components)
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)
print("Original Shape:",X.shape)
print("Reduced Shape after PCA:",X_pca.shape)


Output:
Original Shape: (398, 7)
Reduced Shape after PCA: (398, 2)
